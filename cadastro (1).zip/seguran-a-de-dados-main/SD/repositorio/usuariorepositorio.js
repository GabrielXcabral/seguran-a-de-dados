class UsuarioRepositorio{
    constructor(){
        this._contascadastradas = [];
    }

    cadastrar(usuario){
        this._contascadastradas.push(usuario);

    }

    listar(){
        return this._contascadastradas;
    }
    
    logar(email, senha){
      
        let capturado;
        for(let i = 0; i < this._contascadastradas.length; i++){
            let usuariox = this._contascadastradas[i];

            if(email == usuariox._nome && senhaa == usuariox._senha){
                capturado = usuariox;
                return capturado
                
            }


        }  
        return undefined;
    }

    remover (usuario){
        let index = this._contascadastradas.indexOf(usuario);
        this._contascadastradas.splice(index, 1);
    };
 
}