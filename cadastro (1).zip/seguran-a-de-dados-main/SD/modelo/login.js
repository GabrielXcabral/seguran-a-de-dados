class Login{
    constructor(nome, senha){
        this._nome = nome;
        this._senha = senha;
        this._validador = new UsuarioRepositorio;       
    }
    
}